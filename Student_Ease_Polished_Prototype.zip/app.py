
import streamlit as st
import sqlite3
from pathlib import Path

st.set_page_config(page_title="Student Ease", page_icon="🏠", layout="wide")
DB = Path("student_ease.db")

def db():
    return sqlite3.connect(DB, check_same_thread=False)

def init_db():
    con=db(); c=con.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT, email TEXT UNIQUE, password TEXT, role TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS listings(
        id INTEGER PRIMARY KEY AUTOINCREMENT, owner_email TEXT, title TEXT,
        kind TEXT, audience TEXT, college TEXT, area TEXT, room_type TEXT,
        rent INTEGER, food INTEGER, distance REAL, gender TEXT, contact TEXT,
        description TEXT, amenities TEXT, icon TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS saved(
        email TEXT, listing_id INTEGER, UNIQUE(email,listing_id))""")
    c.execute("""CREATE TABLE IF NOT EXISTS enquiries(
        id INTEGER PRIMARY KEY AUTOINCREMENT, student_email TEXT,
        listing_id INTEGER, message TEXT)""")
    if c.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        c.executemany("INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)",[
            ("Demo Student","student@demo.com","1234","student"),
            ("Demo Owner","owner@demo.com","1234","owner")])
    if c.execute("SELECT COUNT(*) FROM listings").fetchone()[0] == 0:
        data=[
        ("owner@demo.com","Green Nest PG","PG","College Student","Deogiri College","Chhatrapati Sambhajinagar","Double Sharing",4800,2200,.7,"Any","9876543210","Clean student PG with a study-friendly environment.","Wi-Fi • Study Table • CCTV • Laundry","🏠"),
        ("owner@demo.com","Campus Corner","PG","CET/JEE","Deogiri College","Chhatrapati Sambhajinagar","Triple Sharing",3500,2000,1.0,"Any","9876543211","Budget-friendly option for entrance-exam students.","Wi-Fi • Study Room • Food","🎓"),
        ("owner@demo.com","Aai's Home Mess","Mess","11th/12th","Deogiri College","Chhatrapati Sambhajinagar","Monthly",1800,1800,.4,"Any","9876543212","Home-style monthly food plan near the college.","Breakfast • Lunch • Dinner","🍱"),
        ("owner@demo.com","Scholar Stay","Hostel","College Student","CSMSS College","Chhatrapati Sambhajinagar","Single",6500,2500,.9,"Any","9876543213","Single rooms with study facilities.","Study Table • Wi-Fi • Security • Laundry","🛏️"),
        ("owner@demo.com","Sahyadri Boys PG","PG","CET/JEE","MIT College","Chhatrapati Sambhajinagar","Double Sharing",4200,2100,1.3,"Male","9876543214","Affordable student PG.","Wi-Fi • CCTV • Food • Parking","👨‍🎓"),
        ("owner@demo.com","Aarohi Girls PG","PG","College Student","Deogiri College","Chhatrapati Sambhajinagar","Double Sharing",5200,2300,.6,"Female","9876543215","Girls-only PG with security.","CCTV • Security • Wi-Fi • Food","👩‍🎓")]
        c.executemany("""INSERT INTO listings
        (owner_email,title,kind,audience,college,area,room_type,rent,food,distance,gender,contact,description,amenities,icon)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",data)
    con.commit(); con.close()

init_db()

def q(sql,p=(),one=False):
    con=db(); c=con.cursor(); c.execute(sql,p)
    r=c.fetchone() if one else c.fetchall(); con.commit(); con.close(); return r

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
html,body,[class*="css"]{font-family:Inter,sans-serif}
.block-container{padding-top:1.2rem;max-width:1250px}
.hero{background:linear-gradient(135deg,#172554,#2563eb 55%,#06b6d4);color:white;padding:40px;border-radius:24px;margin-bottom:24px}
.hero h1{font-size:44px;margin:0 0 8px;font-weight:800}.hero p{font-size:18px;margin:0;opacity:.92}
.badge{display:inline-block;padding:5px 10px;border-radius:999px;background:#eff6ff;color:#1d4ed8;font-size:12px;font-weight:700;margin-right:5px}
.price{font-size:27px;font-weight:800;color:#111827}.muted{color:#64748b;font-size:13px}
</style>
""",unsafe_allow_html=True)

if "user" not in st.session_state: st.session_state.user=None
if "page" not in st.session_state: st.session_state.page="home"
if "selected" not in st.session_state: st.session_state.selected=None
if "quick" not in st.session_state: st.session_state.quick="All"

def card(r):
    saved=bool(st.session_state.user and q("SELECT 1 FROM saved WHERE email=? AND listing_id=?",
        (st.session_state.user["email"],r[0]),one=True))
    with st.container(border=True):
        a,b=st.columns([1,4])
        with a: st.markdown(f"<div style='font-size:55px;text-align:center'>{r[15]}</div>",unsafe_allow_html=True)
        with b:
            st.markdown(f"### {r[2]}")
            st.markdown(f"<span class='badge'>{r[3]}</span><span class='badge'>{r[4]}</span><span class='badge'>{r[7]}</span>",unsafe_allow_html=True)
            st.write(f"📍 **{r[6]}** • {r[10]} km from {r[5]}")
            st.markdown(f"<span class='price'>₹{r[8]:,}</span> / month  •  Food ₹{r[9]:,}/month",unsafe_allow_html=True)
            st.caption(r[14])
            c1,c2,c3=st.columns(3)
            if c1.button("View details",key=f"v{r[0]}"):
                st.session_state.selected=r[0]; st.session_state.page="details"; st.rerun()
            if st.session_state.user and st.session_state.user["role"]=="student":
                if c2.button("♥ Saved" if saved else "♡ Save",key=f"s{r[0]}"):
                    if saved:q("DELETE FROM saved WHERE email=? AND listing_id=?",(st.session_state.user["email"],r[0]),False)
                    else:q("INSERT OR IGNORE INTO saved VALUES(?,?)",(st.session_state.user["email"],r[0]),False)
                    st.rerun()
            if c3.button("Enquire",key=f"e{r[0]}"):
                st.session_state.selected=r[0]; st.session_state.page="details"; st.rerun()

def home():
    st.markdown("<div class='hero'><h1>🏠 Student Ease</h1><p>Find the right PG, hostel or mess near your college — compare before you choose.</p></div>",unsafe_allow_html=True)
    cols=st.columns(4)
    for c,h,t in zip(cols,["📍 Nearby","💰 Budget-first","🔎 Compare","🤝 Connect"],
                      ["Search around your college","Filter by monthly rent","Compare room & food","Contact owners"]):
        c.metric(h,t)
    st.markdown("### Explore")
    a,b,c=st.columns(3)
    if a.button("🏠 Find PG",use_container_width=True): st.session_state.quick="PG";st.session_state.page="search";st.rerun()
    if b.button("🛏️ Find Hostel",use_container_width=True): st.session_state.quick="Hostel";st.session_state.page="search";st.rerun()
    if c.button("🍱 Find Mess",use_container_width=True): st.session_state.quick="Mess";st.session_state.page="search";st.rerun()
    st.markdown("### How it works")
    st.write("**Choose college → Set budget → Compare options → View details → Contact owner**")

def search():
    st.title("🔎 Find your stay")
    rows=q("SELECT * FROM listings")
    colleges=["All"]+sorted(set(x[5] for x in rows)); areas=["All"]+sorted(set(x[6] for x in rows))
    kinds=["All","PG","Hostel","Mess"]; audiences=["All","11th/12th","CET/JEE","College Student"]
    c1,c2,c3=st.columns(3)
    college=c1.selectbox("College",colleges); area=c2.selectbox("Area",areas)
    kind=c3.selectbox("Type",kinds,index=kinds.index(st.session_state.quick) if st.session_state.quick in kinds else 0)
    c4,c5,c6=st.columns(3)
    audience=c4.selectbox("For",audiences); gender=c5.selectbox("Gender",["Any","Male","Female"])
    maxrent=c6.slider("Maximum rent ₹",1000,15000,10000,500)
    c7,c8=st.columns(2); maxdist=c7.slider("Maximum distance km",.1,5.,3.,.1)
    sort=c8.selectbox("Sort by",["Lowest rent","Nearest college"])
    res=[]
    for r in rows:
        if college!="All" and r[5]!=college:continue
        if area!="All" and r[6]!=area:continue
        if kind!="All" and r[3]!=kind:continue
        if audience!="All" and r[4] not in (audience,"All"):continue
        if gender!="Any" and r[11] not in ("Any",gender):continue
        if r[8]>maxrent or r[10]>maxdist:continue
        res.append(r)
    res.sort(key=lambda x:x[8] if sort=="Lowest rent" else x[10])
    st.markdown(f"**{len(res)} matching options**")
    for r in res: card(r)
    if not res: st.warning("No matching listing. Try a wider budget or distance.")

def details():
    r=q("SELECT * FROM listings WHERE id=?",(st.session_state.selected,),one=True)
    if not r:return
    if st.button("← Back"):st.session_state.page="search";st.rerun()
    st.title(f"{r[15]}  {r[2]}")
    a,b=st.columns([1.5,1])
    with a:
        st.markdown(f"<span class='badge'>{r[3]}</span><span class='badge'>{r[4]}</span><span class='badge'>{r[7]}</span>",unsafe_allow_html=True)
        st.subheader("About this listing");st.write(r[13])
        st.write(f"**College:** {r[5]}");st.write(f"**Area:** {r[6]}");st.write(f"**Distance:** {r[10]} km")
        st.write(f"**Rent:** ₹{r[8]:,}/month");st.write(f"**Food:** ₹{r[9]:,}/month");st.write(f"**Amenities:** {r[14]}")
    with b:
        st.markdown(f"<div style='padding:22px;border:1px solid #e2e8f0;border-radius:18px'><div class='price'>₹{r[8]:,}</div>per month<br><br>📍 {r[6]}<br>🏫 {r[5]}<br>🛏️ {r[7]}</div>",unsafe_allow_html=True)
        st.subheader("📞 Contact")
        if st.session_state.user and st.session_state.user["role"]=="student":
            msg=st.text_area("Message","Hi, I am interested in this listing. Is it available?")
            if st.button("Send enquiry",type="primary",use_container_width=True):
                q("INSERT INTO enquiries(student_email,listing_id,message) VALUES(?,?,?)",(st.session_state.user["email"],r[0],msg),False)
                st.success("Enquiry sent.")
        else:st.info("Login as a student to send an enquiry.")
        st.write(f"☎️ {r[12]}")

def owner():
    st.title("🏢 Owner Dashboard")
    st.caption("Publish structured information for students.")
    with st.form("listing"):
        title=st.text_input("Listing name");kind=st.selectbox("Type",["PG","Hostel","Mess"])
        audience=st.selectbox("Target group",["11th/12th","CET/JEE","College Student","All"])
        college=st.text_input("Nearby college");area=st.text_input("Area / locality")
        room=st.selectbox("Room / plan",["Single","Double Sharing","Triple Sharing","Monthly"])
        rent=st.number_input("Rent ₹/month",0,50000,4000,500);food=st.number_input("Food ₹/month",0,30000,0,100)
        dist=st.number_input("Distance km",0.,20.,1.,.1);gender=st.selectbox("Gender",["Any","Male","Female"])
        contact=st.text_input("Contact number");amen=st.text_input("Amenities","Wi-Fi • Study Table • CCTV")
        desc=st.text_area("Description")
        if st.form_submit_button("Publish listing",type="primary"):
            if not title or not college or not area or not contact:st.error("Fill required fields.")
            else:
                q("""INSERT INTO listings(owner_email,title,kind,audience,college,area,room_type,rent,food,distance,gender,contact,description,amenities,icon)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(st.session_state.user["email"],title,kind,audience,college,area,room,rent,food,dist,gender,contact,desc,amen,"🏠"),False)
                st.success("Listing published.");st.rerun()
    st.subheader("Your listings")
    mine=q("SELECT id,title,kind,college,area,rent FROM listings WHERE owner_email=?",(st.session_state.user["email"],))
    if mine:st.dataframe(mine,use_container_width=True,hide_index=True)
    else:st.info("No listings yet.")

def saved_page():
    st.title("♥ Saved listings")
    rows=q("SELECT l.* FROM listings l JOIN saved s ON l.id=s.listing_id WHERE s.email=?",(st.session_state.user["email"],))
    if not rows:st.info("No saved listings yet.")
    for r in rows:card(r)

def login():
    st.markdown("<div class='hero'><h1>Welcome to Student Ease 👋</h1><p>One place for student stays and food.</p></div>",unsafe_allow_html=True)
    t1,t2=st.tabs(["Login","Create account"])
    with t1:
        email=st.text_input("Email");pw=st.text_input("Password",type="password")
        if st.button("Login",type="primary",use_container_width=True):
            r=q("SELECT name,email,role FROM users WHERE email=? AND password=?",(email,pw),one=True)
            if r:st.session_state.user={"name":r[0],"email":r[1],"role":r[2]};st.session_state.page="search" if r[2]=="student" else "owner";st.rerun()
            else:st.error("Invalid login.")
        st.info("Demo student: student@demo.com / 1234\n\nDemo owner: owner@demo.com / 1234")
    with t2:
        name=st.text_input("Name",key="rn");email=st.text_input("Email",key="re");pw=st.text_input("Password",type="password",key="rp")
        role=st.selectbox("Account type",["student","owner"])
        if st.button("Create account",use_container_width=True):
            try:q("INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)",(name,email,pw,role),False);st.success("Account created.")
            except sqlite3.IntegrityError:st.error("Email already registered.")

with st.sidebar:
    st.markdown("## 🏠 Student Ease")
    if st.session_state.user:
        st.success(f"{st.session_state.user['name']}\n\n{st.session_state.user['role'].title()}")
        if st.button("🏠 Home",use_container_width=True):st.session_state.page="home";st.rerun()
        if st.button("🔎 Search",use_container_width=True):st.session_state.page="search";st.rerun()
        if st.session_state.user["role"]=="student":
            if st.button("♥ Saved",use_container_width=True):st.session_state.page="saved";st.rerun()
        else:
            if st.button("🏢 Owner Dashboard",use_container_width=True):st.session_state.page="owner";st.rerun()
        if st.button("Logout",use_container_width=True):
            st.session_state.user=None;st.session_state.page="home";st.rerun()
    else:
        if st.button("Login / Sign up",use_container_width=True):st.session_state.page="login";st.rerun()
        if st.button("Explore demo",use_container_width=True):st.session_state.page="search";st.rerun()

if st.session_state.page=="home":home()
elif st.session_state.page=="search":search()
elif st.session_state.page=="details":details()
elif st.session_state.page=="owner":owner()
elif st.session_state.page=="saved":saved_page()
else:login()
