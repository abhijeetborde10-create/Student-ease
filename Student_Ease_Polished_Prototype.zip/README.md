# Student Ease — Polished Working Prototype

## Features
- Modern Student Ease UI
- Student and owner accounts
- PG / Hostel / Mess categories
- 11th/12th, CET/JEE and college-student sections
- College and locality filters
- Rent and distance filters
- Lowest-rent and nearest sorting
- Listing details
- Save listings
- Student enquiry
- Owner dashboard and listing publishing
- SQLite local database with demo data

## Run
Install Python 3.10+.

Open terminal in this folder:
```bash
pip install -r requirements.txt
streamlit run app.py
```

Demo student:
student@demo.com / 1234

Demo owner:
owner@demo.com / 1234

## Prototype limitation
This is a college-project MVP, not a production marketplace. A real launch should add secure password hashing, verified owners/listings, image uploads, maps, cloud database, moderation, reviews, notifications and privacy/security controls.
